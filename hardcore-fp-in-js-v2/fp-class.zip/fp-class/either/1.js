const findColor = name =>
  ({red: '#ff4444', blue: '#3b5998', yellow: '#fff68f'}[name])

const res = findColor('red')

console.log(res)
